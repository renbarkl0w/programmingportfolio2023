class Snake(object):
    
    # Intergers
    global xpos
    global ypos
  
    # Constructor
    def __init__(self, size):
        self.x = 3 * size
        self.y = 3 * size
        self.vx = 1
        self.vy = 0
        self.size = size
    
        self.body = [
        (self.x - size, self.y),
        (self.x - size * 2, self.y)
        ]
        
    def update(self):
        self.body.pop(0)
        self.body.append((self.x, self.y))
        self.x += self.vx * self.size
        self.y += self.vy * self.size        

    def action(self, dir): # Move Method for Snake
        print("move: "+dir)
        if key == "w" and self.vy != 1:
            self.vx = 0
            self.vy = -1
        if key == "a" and self.vx != 1:
            self.vx = -1
            self.vy = 0
        if key == "s" and self.vy != -1:
            self.vx = 0
            self.vy = 1
        if key == "d" and self.vx != -1:
            self.vx = 1
            self.vy = 0
            
    
    def draw(self): # Display Method for Snake
        fill(255)
        rect(self.x, self.y, self.size, self.size)
        for part in self.body:
            rect(part[0], part[1], self.size, self.size) # each square is 65/65 - first colum of squares is at 92
    
    # def grow(self):
    #    self.grow

    def intersect(Food, food):
        d = dist(x, y, food.x, food.y)
        if (d<50):
            return True
        else: 
            return False
