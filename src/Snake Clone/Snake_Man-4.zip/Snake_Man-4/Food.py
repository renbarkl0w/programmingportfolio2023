class Food(object):
    
# Intergers
    x = 0
    y = 0
    diam = 0

# Constructor        
    def __init__(self):
        self.x = 100
        self.y = 100
       # self.diam = 1,1
       # self.rand = random(3)
            
        #food_img = random.choice(['appleXuanthaoT.png', 'bananaXuanthaoT.png'])
        #image(loadImage(food_img), 0, 0)
        
    def draw(self): # Display Method for Food
        #img = random.choice(["appleXuanthaoT.png", "bananaXuanthaoT.png"])
        img = "appleXuanthaoT.png"
        #image(loadImage(img), GRID_SIZE, GRID_SIZE, 100, 100)
        
    def move(self): # Move Method for Food
        self.x
        self.y
        for i in range(x, y):
            r = random(x, y)
            r.display()
            
    def intersect(Snake, snake):
        s = dist(x, y, snake.x, snake.y)
        if (s < GRID_SIZE):
            return True
        else: 
            return False
